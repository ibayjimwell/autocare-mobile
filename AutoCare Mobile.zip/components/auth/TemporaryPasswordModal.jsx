
import React, {
  useEffect,
  useState,
} from 'react';

import {
  View,
  Text,
  TextInput,
  TouchableOpacity,
  ActivityIndicator,
  Modal,
  ScrollView,
  KeyboardAvoidingView,
  Platform,
} from 'react-native';

import {
  LockKeyhole,
  Eye,
  EyeOff,
  CheckCircle2,
  AlertCircle,
  ShieldCheck,
  X,
} from 'lucide-react-native';

import {
  theme,
} from '../../theme';

import {
  validateSignupField,
} from '../../utils/validation';

export default function TemporaryPasswordModal({
  visible,
  loading,
  serverError,
  onSubmit,
  onCancel,
}) {
  const [
    password,
    setPassword,
  ] = useState('');

  const [
    confirmPassword,
    setConfirmPassword,
  ] = useState('');

  const [
    showPassword,
    setShowPassword,
  ] = useState(false);

  const [
    showConfirm,
    setShowConfirm,
  ] = useState(false);

  const [
    touched,
    setTouched,
  ] = useState({});

  const [
    submitted,
    setSubmitted,
  ] = useState(false);

  useEffect(() => {
    if (visible) {
      setPassword('');
      setConfirmPassword('');

      setShowPassword(false);
      setShowConfirm(false);

      setTouched({});
      setSubmitted(false);
    }
  }, [visible]);

  const values = {
    password,
    confirmPassword,
  };

  const passwordValidation =
    validateSignupField(
      'password',
      values,
    );

  const confirmValidation =
    validateSignupField(
      'confirmPassword',
      values,
    );

  const passwordError =
    touched.password || submitted
      ? passwordValidation.error
      : '';

  const confirmationError =
    touched.confirmPassword ||
    submitted
      ? (
          !confirmPassword
            ? 'Please confirm your new password.'
            : confirmValidation.error
        )
      : '';

  function submit() {
    setSubmitted(true);

    if (
      !passwordValidation.valid ||
      !confirmPassword ||
      !confirmValidation.valid
    ) {
      return;
    }

    void onSubmit(
      password,
      confirmPassword,
    );
  }

  return (
    <Modal
      visible={visible}
      transparent
      animationType="fade"
      statusBarTranslucent
      onRequestClose={() => {
        if (!loading) {
          onCancel();
        }
      }}
    >
      <KeyboardAvoidingView
        className="flex-1 justify-center bg-black/55 px-4"
        behavior={
          Platform.OS === 'ios'
            ? 'padding'
            : undefined
        }
      >
        <View className="w-full max-w-[440px] self-center overflow-hidden rounded-3xl bg-card shadow-2xl">
          <ScrollView
            keyboardShouldPersistTaps="handled"
            showsVerticalScrollIndicator={false}
            contentContainerStyle={{
              padding: 24,
            }}
          >
            <View className="flex-row items-start justify-between">
              <View className="h-14 w-14 items-center justify-center rounded-2xl bg-primary/10">
                <LockKeyhole
                  size={26}
                  color={theme.primary}
                />
              </View>

              <TouchableOpacity
                onPress={onCancel}
                disabled={loading}
                className="h-11 w-11 items-center justify-center rounded-full bg-secondary"
                accessibilityLabel="Cancel password setup and return to login"
              >
                <X
                  size={21}
                  color={
                    theme[
                      'muted-foreground'
                    ]
                  }
                />
              </TouchableOpacity>
            </View>

            <Text className="mt-5 text-2xl font-bold text-foreground">
              Set your password
            </Text>

            <Text className="mt-2 text-sm leading-5 text-muted-foreground">
              You signed in using a temporary password issued by AutoCare.
              For your account security, create a permanent password before continuing.
            </Text>

            <View className="mt-5 flex-row items-center rounded-xl border border-primary/20 bg-primary/5 p-3">
              <ShieldCheck
                size={19}
                color={theme.primary}
              />

              <Text className="ml-2 flex-1 text-xs leading-5 text-foreground">
                Use at least 6 characters, the same requirement as Sign-up.
              </Text>
            </View>

            <Text className="mb-2 mt-6 text-sm font-semibold text-foreground">
              New password
            </Text>

            <View
              className={`h-12 flex-row items-center rounded-xl border bg-input px-3 ${
                passwordError
                  ? 'border-destructive'
                  : 'border-input'
              }`}
            >
              <TextInput
                value={password}
                onChangeText={value => {
                  setPassword(value);

                  setTouched(prev => ({
                    ...prev,
                    password: true,
                  }));
                }}
                placeholder="Create a new password"
                placeholderTextColor={
                  theme[
                    'muted-foreground'
                  ]
                }
                secureTextEntry={
                  !showPassword
                }
                autoCapitalize="none"
                autoCorrect={false}
                editable={!loading}
                className="h-full flex-1 text-base text-foreground"
              />

              <TouchableOpacity
                onPress={() =>
                  setShowPassword(
                    value => !value,
                  )
                }
                className="h-11 w-11 items-center justify-center"
                accessibilityLabel={
                  showPassword
                    ? 'Hide new password'
                    : 'Show new password'
                }
              >
                {showPassword ? (
                  <EyeOff
                    size={19}
                    color={
                      theme[
                        'muted-foreground'
                      ]
                    }
                  />
                ) : (
                  <Eye
                    size={19}
                    color={
                      theme[
                        'muted-foreground'
                      ]
                    }
                  />
                )}
              </TouchableOpacity>
            </View>

            {passwordError ? (
              <Text className="mt-1 text-sm text-destructive">
                {passwordError}
              </Text>
            ) : password.length > 0 &&
              passwordValidation.valid ? (
              <View className="mt-1 flex-row items-center">
                <CheckCircle2
                  size={14}
                  color={theme.primary}
                />

                <Text className="ml-1 text-xs text-primary">
                  Password meets Sign-up requirements
                </Text>
              </View>
            ) : null}

            <Text className="mb-2 mt-5 text-sm font-semibold text-foreground">
              Confirm new password
            </Text>

            <View
              className={`h-12 flex-row items-center rounded-xl border bg-input px-3 ${
                confirmationError
                  ? 'border-destructive'
                  : 'border-input'
              }`}
            >
              <TextInput
                value={confirmPassword}
                onChangeText={value => {
                  setConfirmPassword(
                    value,
                  );

                  setTouched(prev => ({
                    ...prev,
                    confirmPassword:
                      true,
                  }));
                }}
                placeholder="Re-enter your new password"
                placeholderTextColor={
                  theme[
                    'muted-foreground'
                  ]
                }
                secureTextEntry={
                  !showConfirm
                }
                autoCapitalize="none"
                autoCorrect={false}
                editable={!loading}
                className="h-full flex-1 text-base text-foreground"
              />

              <TouchableOpacity
                onPress={() =>
                  setShowConfirm(
                    value => !value,
                  )
                }
                className="h-11 w-11 items-center justify-center"
                accessibilityLabel={
                  showConfirm
                    ? 'Hide confirmation'
                    : 'Show confirmation'
                }
              >
                {showConfirm ? (
                  <EyeOff
                    size={19}
                    color={
                      theme[
                        'muted-foreground'
                      ]
                    }
                  />
                ) : (
                  <Eye
                    size={19}
                    color={
                      theme[
                        'muted-foreground'
                      ]
                    }
                  />
                )}
              </TouchableOpacity>
            </View>

            {confirmationError ? (
              <Text className="mt-1 text-sm text-destructive">
                {confirmationError}
              </Text>
            ) : confirmPassword.length >
                0 &&
              confirmValidation.valid ? (
              <View className="mt-1 flex-row items-center">
                <CheckCircle2
                  size={14}
                  color={theme.primary}
                />

                <Text className="ml-1 text-xs text-primary">
                  Passwords match
                </Text>
              </View>
            ) : null}

            {serverError ? (
              <View className="mt-5 flex-row rounded-xl border border-destructive/20 bg-destructive/10 p-3">
                <AlertCircle
                  size={17}
                  color={
                    theme.destructive
                  }
                />

                <Text className="ml-2 flex-1 text-sm text-destructive">
                  {serverError}
                </Text>
              </View>
            ) : null}

            <TouchableOpacity
              onPress={submit}
              disabled={loading}
              activeOpacity={0.8}
              className={`mt-6 h-[52px] flex-row items-center justify-center rounded-xl bg-primary ${
                loading
                  ? 'opacity-60'
                  : ''
              }`}
            >
              {loading ? (
                <ActivityIndicator
                  color="#FFFFFF"
                />
              ) : (
                <Text className="text-base font-bold text-white">
                  Save Password & Continue
                </Text>
              )}
            </TouchableOpacity>

            <TouchableOpacity
              onPress={onCancel}
              disabled={loading}
              className="mt-2 h-11 items-center justify-center"
            >
              <Text className="text-sm font-medium text-muted-foreground">
                Back to Login
              </Text>
            </TouchableOpacity>
          </ScrollView>
        </View>
      </KeyboardAvoidingView>
    </Modal>
  );
}
