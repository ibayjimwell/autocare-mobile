import React, { useCallback, useEffect, useRef, useState } from 'react';
import {
  ActivityIndicator,
  Alert,
  AppState,
  Image,
  Linking,
  Modal,
  Text,
  TouchableOpacity,
  View,
} from 'react-native';
import { CheckCircle2, ChevronRight, CreditCard, RotateCw, ShieldCheck, XCircle } from 'lucide-react-native';
import paymentsApi from '../../services/paymentsApi';
import { useTheme } from '../../context/ThemeContext';

const METHODS = [
  { id: 'gcash', label: 'GCash', logo: require('../../assets/gcash.png') },
  { id: 'paymaya', label: 'Maya', logo: require('../../assets/maya.png') },
  { id: 'card', label: 'Credit / Debit Card', logo: require('../../assets/card.png') },
];

const OPEN_STATUSES = ['PENDING', 'ACTIVE', 'CREATING', 'CREATE_UNKNOWN', 'PROCESSING'];
const amountText = amount => `₱${Number(amount || 0).toLocaleString('en-PH', { minimumFractionDigits: 2, maximumFractionDigits: 2 })}`;

function PaymentLogo({ method }) {
  return (
    <View className="h-12 w-20 items-center justify-center rounded-xl border border-[#e8ebf0] bg-white px-2">
      <Image source={method.logo} resizeMode="contain" style={{ width: 70, height: 34 }} accessibilityLabel={`${method.label} logo`} />
    </View>
  );
}

function errorMessage(cause, fallback) {
  const message = String(cause?.errorMessage || cause?.message || '').trim();
  if (cause?.status === 404 && /checkout/i.test(message)) return 'Checkout is unavailable. Please use another payment option.';
  return message || fallback;
}

/**
 * When the backend is configured for an isolated capstone database, payment
 * selections can demonstrate the entire settlement flow without real funds.
 * Hosted PayMongo checkout remains available and QRPh remains separate.
 */
export default function HostedCheckoutMethods({ billId, amount, onConfirmedPayment, returnFlag }) {
  const { theme } = useTheme();
  const [demoEnabled, setDemoEnabled] = useState(false);
  const [selected, setSelected] = useState(null);
  const [busy, setBusy] = useState(false);
  const [checking, setChecking] = useState(false);
  const [status, setStatus] = useState('NONE');
  const [method, setMethod] = useState(null);
  const [checkoutUrl, setCheckoutUrl] = useState(null);
  const [liveMode, setLiveMode] = useState(null);
  const [error, setError] = useState('');
  const [demoTicket, setDemoTicket] = useState(null);
  const [demoMethod, setDemoMethod] = useState(null);
  const [demoResult, setDemoResult] = useState(null);
  const [demoVisible, setDemoVisible] = useState(false);
  const [demoBusy, setDemoBusy] = useState(false);
  const checkingRef = useRef(false);
  const mountedRef = useRef(true);
  const notifiedRef = useRef(false);

  const refresh = useCallback(async () => {
    if (!billId || checkingRef.current) return;
    checkingRef.current = true;
    if (mountedRef.current) setChecking(true);
    try {
      const response = await paymentsApi.getHostedCheckout(billId);
      const data = response?.data || {};
      if (!mountedRef.current) return;
      setStatus(data.status || 'NONE');
      setMethod(data.paymentMethod || null);
      setCheckoutUrl(data.checkoutUrl || null);
      if (typeof data.livemode === 'boolean') setLiveMode(data.livemode);
      if (data.paid && !notifiedRef.current) {
        notifiedRef.current = true;
        onConfirmedPayment?.();
      }
    } catch (cause) {
      if (mountedRef.current) setError(errorMessage(cause, 'Unable to check your PayMongo checkout.'));
    } finally {
      checkingRef.current = false;
      if (mountedRef.current) setChecking(false);
    }
  }, [billId, onConfirmedPayment]);

  useEffect(() => {
    mountedRef.current = true;
    notifiedRef.current = false;
    setDemoEnabled(false);
    if (billId) {
      void paymentsApi.getDemoCheckout(billId).then(response => {
        if (mountedRef.current) setDemoEnabled(response?.data?.enabled === true);
      }).catch(() => {});
      void refresh();
    }
    const subscription = AppState.addEventListener('change', state => {
      if (state === 'active') void refresh();
    });
    return () => { mountedRef.current = false; subscription.remove(); };
  }, [billId, refresh]);

  useEffect(() => {
    if (returnFlag) void refresh();
  }, [returnFlag, refresh]);

  useEffect(() => {
    if (!OPEN_STATUSES.includes(status)) return undefined;
    const timer = setInterval(() => void refresh(), 8000);
    return () => clearInterval(timer);
  }, [status, refresh]);

  const openCheckout = async url => {
    if (typeof url !== 'string' || !/^https:\/\/checkout\.paymongo\.com\//.test(url)) {
      throw new Error('The secure checkout link is unavailable.');
    }
    await Linking.openURL(url);
  };

  const choosePayMongo = async paymentMethod => {
    if (busy || checking || demoBusy) return;
    setBusy(true);
    setSelected(paymentMethod);
    setError('');
    try {
      const response = await paymentsApi.createHostedCheckout(billId, paymentMethod);
      const data = response?.data || {};
      if (!data.checkoutUrl) throw new Error('PayMongo did not return a checkout link.');
      setStatus('ACTIVE');
      setMethod(paymentMethod);
      setCheckoutUrl(data.checkoutUrl);
      if (typeof data.livemode === 'boolean') setLiveMode(data.livemode);
      await openCheckout(data.checkoutUrl);
    } catch (cause) {
      const message = errorMessage(cause, 'Unable to prepare your payment.');
      setError(message);
      Alert.alert('Unable to start checkout', message);
      void refresh();
    } finally {
      if (mountedRef.current) { setBusy(false); setSelected(null); }
    }
  };

  const startDemo = async paymentMethod => {
    if (busy || checking || demoBusy) return;
    setBusy(true);
    setSelected(paymentMethod);
    setError('');
    try {
      const response = await paymentsApi.runDemoCheckout(billId, 'start', { paymentMethod });
      const data = response?.data || {};
      if (!data.token) throw new Error('Unable to initialize the demonstration checkout.');
      setDemoTicket(data.token);
      setDemoMethod(paymentMethod);
      setDemoResult(null);
      setDemoVisible(true);
    } catch (cause) {
      const message = errorMessage(cause, 'Unable to start demonstration checkout.');
      setError(message);
      Alert.alert('Checkout unavailable', message);
    } finally {
      if (mountedRef.current) { setBusy(false); setSelected(null); }
    }
  };

  const settleDemo = async action => {
    if (!demoTicket || demoBusy) return;
    setDemoBusy(true);
    try {
      const response = await paymentsApi.runDemoCheckout(billId, action, { token: demoTicket });
      const data = response?.data || {};
      if (action === 'complete' && data.paid !== true) throw new Error('The Final Cost was not marked as paid.');
      setDemoResult(action === 'complete' ? 'PAID' : action === 'decline' ? 'FAILED' : 'CANCELLED');
      setDemoTicket(null);
      if (action === 'complete') {
        setDemoVisible(false);
        notifiedRef.current = true;
        onConfirmedPayment?.();
      }
    } catch (cause) {
      const message = errorMessage(cause, 'Could not complete the demonstration checkout.');
      Alert.alert('Payment not completed', message);
      setError(message);
    } finally {
      if (mountedRef.current) setDemoBusy(false);
    }
  };

  const cancelHosted = () => {
    Alert.alert('Cancel current checkout?', 'Cancel the current PayMongo payment session before selecting another method.', [
      { text: 'Keep checkout', style: 'cancel' },
      { text: 'Cancel checkout', style: 'destructive', onPress: async () => {
        setBusy(true);
        try {
          await paymentsApi.cancelHostedCheckout(billId);
          setStatus('EXPIRED');
          setCheckoutUrl(null);
          setMethod(null);
          setError('');
        } catch (cause) {
          Alert.alert('Unable to cancel checkout', errorMessage(cause, 'Please check your payment status.'));
        } finally { setBusy(false); void refresh(); }
      } },
    ]);
  };

  const demoMethodInfo = METHODS.find(item => item.id === demoMethod);

  return (
    <View className="mb-4">
      <View className="mb-3 flex-row items-center justify-between px-1">
        <View className="flex-row items-center">
          <CreditCard color={theme.primary} size={18} />
          <Text className="ml-2 text-sm font-bold text-foreground">Pay Online</Text>
        </View>
        <View className="flex-row items-center">
          <ShieldCheck size={14} color="#16a34a" />
          <Text className="ml-1 text-xs text-muted-foreground">Secure checkout</Text>
        </View>
      </View>

      {demoEnabled && (
        <View className="mb-3 rounded-xl border border-[#c4d7fa] bg-[#f0f5ff] p-3">
          <Text className="text-sm font-bold text-[#174a83]">Capstone demonstration</Text>
          <Text className="mt-1 text-xs leading-5 text-[#315d88]">
            Simulated payments update the demonstration Final Cost. No real money is transferred or collected.
          </Text>
        </View>
      )}

      <View className="overflow-hidden rounded-2xl border border-border bg-card">
        <Text className="border-b border-border px-4 py-4 text-base font-bold text-foreground">Choose a payment method</Text>
        {METHODS.map((item, index) => {
          const otherOpen = OPEN_STATUSES.includes(status) && method !== item.id;
          const disabled = busy || checking || demoBusy || otherOpen || status === 'PAID' || status === 'DEMO_PAID';
          return (
            <TouchableOpacity
              key={item.id}
              accessibilityRole="button"
              accessibilityLabel={`Pay ${amountText(amount)} with ${item.label}`}
              activeOpacity={0.78}
              disabled={disabled}
              onPress={() => {
                const action = demoEnabled ? startDemo : choosePayMongo;
                void action(item.id);
              }}
              className={`min-h-[80px] flex-row items-center px-4 ${index !== METHODS.length - 1 ? 'border-b border-border' : ''}`}
              style={{ opacity: otherOpen ? 0.4 : 1 }}
            >
              <PaymentLogo method={item} />
              <Text className="ml-3 flex-1 text-base font-semibold text-foreground">{item.label}</Text>
              {busy && selected === item.id ? <ActivityIndicator color={theme.primary} /> : <ChevronRight color={theme.textSecondary} size={20} />}
            </TouchableOpacity>
          );
        })}
      </View>

      {demoEnabled && (
        <View className="mt-4">
          <Text className="mb-2 px-1 text-xs font-semibold text-muted-foreground">PayMongo Sandbox Checkout</Text>
          <View className="flex-row gap-2">
            {METHODS.map(item => (
              <TouchableOpacity key={item.id} onPress={() => { void choosePayMongo(item.id); }}
                disabled={busy || checking || demoBusy || OPEN_STATUSES.includes(status)}
                accessibilityRole="button"
                className="min-h-[44px] flex-1 items-center justify-center rounded-xl border border-border bg-card px-1">
                <Text className="text-center text-xs font-semibold text-primary">{item.id === 'card' ? 'Card' : item.label}</Text>
              </TouchableOpacity>
            ))}
          </View>
        </View>
      )}

      {OPEN_STATUSES.includes(status) && (
        <View className="mt-3 rounded-xl border border-border bg-card p-4">
          <View className="flex-row items-center"><ActivityIndicator size="small" color={theme.primary} />
            <Text className="ml-2 text-sm font-semibold text-foreground">Checkout awaiting confirmation</Text></View>
          <Text className="mt-2 text-xs leading-5 text-muted-foreground">Complete the payment at PayMongo and return to AutoCare.</Text>
          <View className="mt-3 flex-row gap-2">
            {checkoutUrl && <TouchableOpacity onPress={() => void openCheckout(checkoutUrl).catch(cause => Alert.alert('Checkout unavailable', cause.message))}
              className="min-h-[44px] flex-1 items-center justify-center rounded-xl bg-primary"><Text className="text-sm font-semibold text-white">Resume checkout</Text></TouchableOpacity>}
            <TouchableOpacity onPress={cancelHosted} disabled={busy} className="min-h-[44px] flex-1 items-center justify-center rounded-xl border border-border bg-card"><Text className="text-sm font-semibold text-foreground">Cancel checkout</Text></TouchableOpacity>
          </View>
        </View>
      )}
      {status === 'SIMULATED' && (
        <View className="mt-3 rounded-xl border border-amber-200 bg-amber-50 p-3">
          <Text className="text-sm font-semibold text-amber-900">Sandbox payment confirmed</Text>
          <Text className="mt-1 text-xs leading-5 text-amber-800">
            The transaction succeeded in PayMongo, but this Final Cost has not yet been marked paid.
            Refresh the payment status once demonstration settlement is available.
          </Text>
        </View>
      )}
      {status === 'DEMO_PAID' && <View className="mt-3 rounded-xl border border-green-200 bg-green-50 p-3"><Text className="text-sm font-semibold text-green-800">Demonstration Final Cost marked paid.</Text></View>}
      {status === 'CREATE_UNKNOWN' && <View className="mt-3 rounded-xl border border-amber-200 bg-amber-50 p-3"><Text className="text-sm text-amber-800">Checkout setup could not be confirmed. Contact AutoCare before attempting another payment.</Text></View>}
      {!!error && <View className="mt-3 rounded-xl border border-red-200 bg-red-50 p-3"><Text className="text-xs text-red-800">{error}</Text></View>}
      <TouchableOpacity onPress={() => void refresh()} disabled={checking || busy} className="mt-2 min-h-[44px] flex-row items-center justify-center" accessibilityRole="button">
        {checking ? <ActivityIndicator size="small" color={theme.primary}/> : <RotateCw size={16} color={theme.primary} />}
        <Text className="ml-2 text-sm font-semibold text-primary">{checking ? 'Checking payment...' : 'Check payment status'}</Text>
      </TouchableOpacity>

      <Modal visible={demoVisible} animationType="slide" transparent onRequestClose={() => { if (!demoBusy) setDemoVisible(false); }}>
        <View className="flex-1 justify-end bg-black/50">
          <View className="rounded-t-3xl bg-card px-5 pb-10 pt-5">
            <View className="mb-4 flex-row items-center justify-between">
              <Text className="text-xl font-bold text-foreground">Payment confirmation</Text>
              <TouchableOpacity accessibilityRole="button" accessibilityLabel="Close checkout" disabled={demoBusy} onPress={() => { setDemoVisible(false); setDemoTicket(null); }} className="h-11 w-11 items-center justify-center rounded-full bg-background">
                <XCircle size={23} color={theme.textSecondary}/>
              </TouchableOpacity>
            </View>
            <View className="items-center rounded-2xl border border-border bg-background p-5">
              {!!demoMethodInfo && <PaymentLogo method={demoMethodInfo}/>}
              <Text className="mt-3 text-base font-semibold text-foreground">{demoMethodInfo?.label || 'Online payment'}</Text>
              <Text className="mt-2 text-3xl font-bold text-foreground">{amountText(amount)}</Text>
              <Text className="mt-2 text-center text-xs leading-5 text-muted-foreground">Capstone simulation only. No payment is sent to GCash, Maya, or your bank.</Text>
            </View>
            {demoResult ? (
              <View className={`mt-4 rounded-xl p-4 ${demoResult === 'FAILED' ? 'bg-red-50' : 'bg-background'}`}>
                <Text className="text-center text-sm font-semibold text-foreground">{demoResult === 'FAILED' ? 'Payment declined. Final Cost remains unpaid.' : 'Checkout cancelled. No charge was made.'}</Text>
                <TouchableOpacity onPress={() => setDemoVisible(false)} className="mt-3 min-h-[48px] items-center justify-center rounded-xl bg-primary"><Text className="font-semibold text-white">Close</Text></TouchableOpacity>
              </View>
            ) : (
              <>
                <TouchableOpacity disabled={demoBusy} onPress={() => void settleDemo('complete')} className="mt-5 min-h-[52px] flex-row items-center justify-center rounded-xl bg-primary">
                  {demoBusy ? <ActivityIndicator size="small" color="#fff"/> : <CheckCircle2 color="#fff" size={19}/>}
                  <Text className="ml-2 text-base font-semibold text-white">Confirm simulated payment</Text>
                </TouchableOpacity>
                <TouchableOpacity disabled={demoBusy} onPress={() => void settleDemo('decline')} className="mt-2 min-h-[48px] items-center justify-center rounded-xl border border-border bg-card"><Text className="font-semibold text-foreground">Simulate declined payment</Text></TouchableOpacity>
                <TouchableOpacity disabled={demoBusy} onPress={() => void settleDemo('cancel')} className="min-h-[44px] items-center justify-center"><Text className="text-sm text-muted-foreground">Cancel</Text></TouchableOpacity>
              </>
            )}
          </View>
        </View>
      </Modal>
    </View>
  );
}
