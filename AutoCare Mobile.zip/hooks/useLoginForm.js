
import {
  useRef,
  useState,
} from 'react';

import {
  router,
} from 'expo-router';

import {
  useAuth,
} from '../context/AuthContext';

import authApi from '../services/authApi';

import {
  loginSchema,
  signupSchema,
} from '../utils/validation';

function errorMessage(
  error,
  fallback,
) {
  return (
    error?.errorMessage ||
    error?.response?.data?.errorMessage ||
    error?.message ||
    fallback
  );
}

function isDeactivated(error) {
  const status =
    error?.status ??
    error?.statusCode ??
    error?.response?.status;

  const title =
    error?.errorTitle ??
    error?.response?.data?.errorTitle;

  const message =
    errorMessage(error, '')
      .toLowerCase();

  return (
    status === 403 ||
    title === 'Account deactivated' ||
    message.includes(
      'account is deactivated',
    )
  );
}

export function useLoginForm() {
  const {
    setSession,
  } = useAuth();

  // FORM
  const [
    emailOrPhone,
    setEmailOrPhone,
  ] = useState('');

  const [
    password,
    setPassword,
  ] = useState('');

  const [
    showPassword,
    setShowPassword,
  ] = useState(false);

  const [
    loading,
    setLoading,
  ] = useState(false);

  const [
    errors,
    setErrors,
  ] = useState({});

  const [
    loginError,
    setLoginError,
  ] = useState('');

  // DEACTIVATED ACCOUNT
  const [
    deactivatedModalVisible,
    setDeactivatedModalVisible,
  ] = useState(false);

  // TEMPORARY PASSWORD
  const [
    tempPasswordModalVisible,
    setTempPasswordModalVisible,
  ] = useState(false);

  const [
    changingPassword,
    setChangingPassword,
  ] = useState(false);

  const [
    tempPasswordError,
    setTempPasswordError,
  ] = useState('');

  // Store pending credentials in memory only.
  // Never save the original temporary password
  // or temporary login token in persistent storage.
  const pendingLoginRef =
    useRef(null);

  function handleFieldChange(
    field,
    value,
  ) {
    if (
      field === 'emailOrPhone'
    ) {
      setEmailOrPhone(value);
    }

    if (
      field === 'password'
    ) {
      setPassword(value);
    }

    setErrors(previous => ({
      ...previous,
      [field]: '',
    }));

    setLoginError('');
  }

  function closeDeactivatedModal() {
    setDeactivatedModalVisible(
      false,
    );
  }

  function cancelTemporaryPasswordChange() {
    if (changingPassword) {
      return;
    }

    pendingLoginRef.current =
      null;

    setTempPasswordError('');

    setTempPasswordModalVisible(
      false,
    );
  }

  // LOGIN
  async function handleLogin() {
    if (
      loading ||
      changingPassword ||
      tempPasswordModalVisible
    ) {
      return;
    }

    setLoginError('');

    setDeactivatedModalVisible(
      false,
    );

    const parsed =
      loginSchema.safeParse({
        emailOrPhone,
        password,
      });

    if (!parsed.success) {
      const nextErrors = {};

      for (
        const issue of
        parsed.error.issues
      ) {
        const key =
          issue.path?.[0];

        if (
          key &&
          !nextErrors[key]
        ) {
          nextErrors[key] =
            issue.message;
        }
      }

      setErrors(nextErrors);
      return;
    }

    setErrors({});
    setLoading(true);

    try {
      const result =
        await authApi.login({
          emailOrPhone:
            emailOrPhone.trim(),
          password,
        });

      // API ERROR
      if (result?.error) {
        if (
          isDeactivated(result)
        ) {
          setDeactivatedModalVisible(
            true,
          );
          return;
        }

        setLoginError(
          errorMessage(
            result,
            'Login failed. Please try again.',
          ),
        );

        return;
      }

      // PHONE VERIFICATION
      if (
        result?.data
          ?.requiresVerification
      ) {
        const {
          customerId,
          phone,
        } = result.data;

        if (
          !customerId ||
          !phone
        ) {
          setLoginError(
            'Phone verification information is missing.',
          );
          return;
        }

        router.replace(
          `/verify-phone?customerId=${encodeURIComponent(
            customerId,
          )}` +
          `&phone=${encodeURIComponent(
            phone,
          )}`,
        );

        return;
      }

      // CUSTOMER SESSION DATA
      const customer =
        result?.data?.customer;

      const token =
        result?.data?.token;

      if (
        !customer?.id ||
        !token
      ) {
        setLoginError(
          'Login response is missing customer or token.',
        );
        return;
      }

      if (
        customer.deactivated ===
        true
      ) {
        setDeactivatedModalVisible(
          true,
        );
        return;
      }

      // TEMPORARY PASSWORD DETECTED
      if (
        customer.tempPassword ===
        true
      ) {
        // Do not establish the session yet.
        pendingLoginRef.current = {
          token,
          customerId:
            customer.id,
          currentPassword:
            password,
        };

        setPassword('');
        setShowPassword(false);

        setTempPasswordError('');

        setTempPasswordModalVisible(
          true,
        );

        return;
      }

      // NORMAL LOGIN
      setSession(
        customer,
        token,
      );

      setPassword('');

      router.replace(
        '/(tabs)',
      );
    } catch (error) {
      if (
        isDeactivated(error)
      ) {
        setDeactivatedModalVisible(
          true,
        );
      } else {
        setLoginError(
          errorMessage(
            error,
            'Login failed. Please try again.',
          ),
        );
      }
    } finally {
      setLoading(false);
    }
  }

  // COMPLETE TEMPORARY PASSWORD CHANGE
  async function submitTemporaryPassword(
    newPassword,
    confirmPassword,
  ) {
    if (
      changingPassword
    ) {
      return false;
    }

    setTempPasswordError('');

    const pending =
      pendingLoginRef.current;

    if (!pending) {
      setTempPasswordError(
        'Temporary login expired. Please sign in again.',
      );

      return false;
    }

    // Use the existing Sign-up password schema.
    const parsed =
      signupSchema.shape.password
        .safeParse(newPassword);

    if (!parsed.success) {
      setTempPasswordError(
        parsed.error.issues[0]
          ?.message ||
        'Invalid password.',
      );

      return false;
    }

    if (
      !confirmPassword ||
      newPassword !==
        confirmPassword
    ) {
      setTempPasswordError(
        'Passwords do not match.',
      );

      return false;
    }

    if (
      newPassword ===
      pending.currentPassword
    ) {
      setTempPasswordError(
        'Choose a different password from the temporary password.',
      );

      return false;
    }

    setChangingPassword(true);

    try {
      const response =
        await authApi.changeTemporaryPassword({
          loginToken:
            pending.token,

          currentPassword:
            pending.currentPassword,

          newPassword,

          confirmPassword,
        });

      if (response?.error) {
        throw new Error(
          errorMessage(
            response,
            'Could not change your password.',
          ),
        );
      }

      const customer =
        response?.data?.customer;

      if (
        !customer?.id ||
        customer.id !==
          pending.customerId ||
        customer.tempPassword !==
          false
      ) {
        throw new Error(
          'The server did not confirm the password change. Please try signing in again.',
        );
      }

      // Only now create the normal session.
      setSession(
        customer,
        pending.token,
      );

      pendingLoginRef.current =
        null;

      setTempPasswordModalVisible(
        false,
      );

      setTempPasswordError('');
      setPassword('');

      router.replace(
        '/(tabs)',
      );

      return true;
    } catch (error) {
      setTempPasswordError(
        errorMessage(
          error,
          'Could not change your password.',
        ),
      );

      return false;
    } finally {
      setChangingPassword(false);
    }
  }

  return {
    emailOrPhone,
    password,
    showPassword,
    setShowPassword,
    loading,
    errors,
    loginError,

    deactivatedModalVisible,
    closeDeactivatedModal,

    tempPasswordModalVisible,
    changingPassword,
    tempPasswordError,

    cancelTemporaryPasswordChange,
    submitTemporaryPassword,

    handleFieldChange,
    handleLogin,
  };
}
